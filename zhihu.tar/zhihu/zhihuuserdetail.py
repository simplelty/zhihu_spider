#coding=utf-8
#抓取所有用户信息
import requests
import re
import sys
import MySQLdb
import os
import cjson
from time import sleep

threadnum = os.popen("ps aux | grep zhihuuserdetail -wc")
num = threadnum.read()
if int(num) > 3:
	print int(num)
	threadnum.close()
	sys.exit()
threadnum.close()


reload(sys)
sys.setrecursionlimit(300000)
sys.setdefaultencoding('utf-8')



class Zhihuuserdetail():
	num = 0
	allurls = {}
	allkey = {}

	def __init__(self):
		self.conn = MySQLdb.connect(
		    host = 'localhost',
		    port = 3306,
		    user = 'root',
		    passwd = 'ybz0628',
		    db = 'zhihudata',
		    charset = 'UTF8',
		)
		self.cur = self.conn.cursor()

	def getusers(self):
		try:
			# sql = "select id,urltoken from zhihuuser order by id asc limit 20192,1000000" #where updatetime is null and company is null"
			sql = "select id,urltoken from zhihuuser where ISNULL(updatetime) limit 10000;"
			self.cur.execute(sql)
			results = self.cur.fetchall()
			for row in results:
				self.allurls[row[0]] = str(row[1])
			self.allkey = sorted(self.allurls.keys())
			self.requestdata(self.allurls[self.allkey[self.num]],self.allkey[self.num])
		except:
		   print "Error: unable to fecth data"

	def requestdata(self, usertoken, index):
		headers = {
		'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
		'Accept-Encoding':'gzip, deflate, sdch, br',
		'Accept-Language':'zh-CN,zh;q=0.8',
		'Cache-Control':'max-age=0',
		'Connection':'keep-alive',
		'Cookie':'d_c0="ACBAa0ulmQqPTrVdyqFVe4G3LZ6CH8jmoaY=|1474889679"; _za=f32d2598-ba48-4298-85a4-16e7340c1cbd; _zap=e443a29c-13bc-4b4c-b6da-eee8c79f9427; login="ZDEzOTdjOTI5NjkzNDM1NGIzYjQ5ZmIwYzM1NzkzNDM=|1480486221|0061a33c20c147447860fd2d9d69c84f4a8ab428"; q_c1=0baee564d3ac4a2a8c9475421ea21cea|1480517926000|1474889678000; a_t="2.0ABCMGsD67QgXAAAAHnJnWAAQjBrA-u0IACBAa0ulmQoXAAAAYQJVTVv6ZVgA6p_ZDJz1uQrJ-BtGz-pkwRGsHOI1nVAvDpSKoAhp-PaBZSjsAyx3Yg=="; _xsrf=593fb28c35c18bbddefa41f1105b3441; __utma=51854390.630733563.1482317052.1482317052.1482317052.1; __utmc=51854390; __utmz=51854390.1482317052.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none); __utmv=51854390.100-1|2=registration_date=20151030=1^3=entry_date=20151030=1; l_cap_id="YjViNmEzZjEzNGU4NGRjNGEyMzkyNjgyMjZmOTEwZTU=|1482320015|1b33cd514463f76c4084e74edcb4c7527903424b"; cap_id="MGZiYTVlNzM5OTk0NDEyOGJlMzIyYmM0MWRlYzhlMzI=|1482320015|19aea96e3c1bbb0923f5b5a92ce956a80a2d0d99"; r_cap_id="YmJhOWZjNTQ2NjlmNGE3NWFkMzdiZmI5ZWZlYTg2NDg=|1482320016|c2aac1e5be1b0a85a579e1d63ff3fcf1f6a1b305"; unlock_ticket="QUdCQ0dCdGVDQXNYQUFBQVlRSlZUZTF2V2xoMmxTanlubmZhMl8yNWlnbmYyb0U2X0s1Um9RPT0=|1482320101|77274a2898517a0344be01d6f6a3d8dcb8c0b145"; s-q=%E6%97%A9%E5%AE%89%E9%98%B3%E5%85%89%E4%B8%B6; s-i=1; sid=il8i6r4o; s-t=autocomplete; z_c0=Mi4wQUdCQ0dCdGVDQXNBSUVCclM2V1pDaGNBQUFCaEFsVk41ZldCV0FCalhVSnNINjdCRXBwQ0VpXzZMdDFTY3V0NEFR|1482320202|124de4c2045aa2ad1489846e488d100278366b1f',
		'Host':'www.zhihu.com',
		'Referer':'https://www.zhihu.com/people/seatory/following',
		'Upgrade-Insecure-Requests':'1',
		'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36',
		}
		userurl = 'https://www.zhihu.com/people/' + usertoken + '/following'
		try:
			result = requests.get(userurl, headers = headers, timeout = 60)
			content = result.text
			content = content.replace('&quot;','"')
			content = content.replace('\\\\','')
			data = re.findall(u'data-state="(.*?)" data-config',content) 
			if len(data):
				b = cjson.decode(data[0].encode('utf-8').decode('utf-8'))
				tmp = b['entities']['users'][usertoken.encode('utf-8').decode('utf-8')]
				sql = "update zhihuuser set name='" + tmp['name'] + "',description='" + tmp['description'] + "',headline='" + tmp['headline'] + "',sex='" + str(tmp['gender']) + "',answer='" + str(tmp['answerCount']) + "',share='" + str(tmp['articlesCount']) + "',question='" + str(tmp['questionCount']) + "',favorite='" + str(tmp['favoriteCount']) + "',address='" + (tmp['locations'][0]['name'] if len(tmp['locations']) != 0 else u'') + "',business='" + (tmp['business']['name'] if tmp.has_key('business') and tmp['business'] != None else u'') + "',company='" + (tmp['employments'][0]['company']['name'] if len(tmp['employments']) and tmp['employments'][0].has_key('company') != 0 else u'') + "',profession='" + (tmp['employments'][0]['job']['name'] if len(tmp['employments']) != 0 and tmp['employments'][0].has_key('job') else u'') + "',school='" + (tmp['educations'][0]['school']['name'] if len(tmp['educations']) != 0 and tmp['educations'][0].has_key('school') else u'') + "',major='" + (tmp['educations'][0]['major']['name'] if len(tmp['educations']) != 0 and tmp['educations'][0].has_key('major') else u'') + "',voteup='" + str(tmp['voteupCount']) + "',thanked='" + str(tmp['thankedCount']) + "',favorited='" + str(tmp['favoritedCount']) + "',following='" + str(tmp['followingCount']) + "',follow='" + str(tmp['followerCount']) + "',followingtopic='" + str(tmp['followingTopicCount']) + "',followingcolumns='" + str(tmp['followingColumnsCount']) + "',followingquestion='" + str(tmp['followingQuestionCount']) + "',followingfavlists='" + str(tmp['followingFavlistsCount']) + "' where id='" + str(index) + "'"
				self.cur.execute(sql)
				self.conn.commit()
				del b
				del sql
				del tmp
			self.i = self.i + 1
			print index
			del result
			del content
			del data
			self.requestdata(self.allurls[self.allkey[self.i]],self.allkey[self.i])
		except Exception, e:
			print str(e)
			pass

if __name__ == '__main__':
	zhihuuserdetail = Zhihuuserdetail()
	zhihuuserdetail.getusers()
	
